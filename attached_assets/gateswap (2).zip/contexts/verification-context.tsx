"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { useRouter, usePathname } from "next/navigation"

interface VerificationContextType {
  isVerified: boolean
  setVerified: (value: boolean) => void
  isLoading: boolean
}

const VerificationContext = createContext<VerificationContextType | undefined>(undefined)

export function VerificationProvider({ children }: { children: ReactNode }) {
  const [isVerified, setIsVerified] = useState<boolean>(false)
  const [isLoading, setIsLoading] = useState<boolean>(true)
  const router = useRouter()
  const pathname = usePathname()

  // Protected routes that require verification
  const protectedRoutes = ["/swap", "/portfolio"]

  // Public routes that don't require verification
  const publicRoutes = ["/", "/verify"]

  useEffect(() => {
    // Check localStorage for verification status
    const checkVerificationStatus = () => {
      const storedStatus = localStorage.getItem("gateswap_verified")
      const verified = storedStatus === "true"
      setIsVerified(verified)
      setIsLoading(false)

      // Handle routing based on verification status
      if (!verified && protectedRoutes.some((route) => pathname?.startsWith(route))) {
        // Redirect to verify if trying to access protected route without verification
        router.replace("/verify")
      } else if (verified && pathname === "/") {
        // Redirect to swap if already verified and on homepage
        router.replace("/swap")
      }
    }

    checkVerificationStatus()
  }, [pathname, router])

  const setVerified = (value: boolean) => {
    // Update state and localStorage
    setIsVerified(value)
    localStorage.setItem("gateswap_verified", value ? "true" : "false")

    // Redirect to swap page if verification is successful
    if (value && pathname === "/verify") {
      router.replace("/swap")
    }
  }

  return (
    <VerificationContext.Provider value={{ isVerified, setVerified, isLoading }}>
      {children}
    </VerificationContext.Provider>
  )
}

export function useVerification() {
  const context = useContext(VerificationContext)
  if (context === undefined) {
    throw new Error("useVerification must be used within a VerificationProvider")
  }
  return context
}

