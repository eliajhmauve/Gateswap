"use client"

import { useState, useEffect, useCallback } from "react"

export type VerificationStatus = "pending" | "verifying" | "verified" | "expired" | "error"

interface VerificationState {
  status: VerificationStatus
  qrCodeUrl: string | null
  sessionId: string | null
  message: string
  error: string | null
}

interface VerificationResponse {
  success: boolean
  data?: {
    qrCodeUrl: string
    sessionId: string
    status: VerificationStatus
    message?: string
  }
  error?: string
}

export function useQRVerification() {
  const [state, setState] = useState<VerificationState>({
    status: "pending",
    qrCodeUrl: null,
    sessionId: null,
    message: "Initializing verification...",
    error: null,
  })

  const [pollingInterval, setPollingInterval] = useState<NodeJS.Timeout | null>(null)

  const fetchQRCode = useCallback(async () => {
    try {
      setState((prev) => ({
        ...prev,
        status: "pending",
        message: "Generating QR code...",
        error: null,
      }))

      const response = await fetch("/api/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      })

      const data: VerificationResponse = await response.json()

      if (!data.success || !data.data) {
        throw new Error(data.error || "Failed to generate QR code")
      }

      setState((prev) => ({
        ...prev,
        status: "pending",
        qrCodeUrl: data.data!.qrCodeUrl,
        sessionId: data.data!.sessionId,
        message: "Please scan the QR code with the Self Protocol app",
      }))

      return data.data.sessionId
    } catch (error) {
      setState((prev) => ({
        ...prev,
        status: "error",
        message: "Failed to generate QR code",
        error: error instanceof Error ? error.message : "Unknown error",
      }))
      return null
    }
  }, [])

  const checkVerificationStatus = useCallback(async (sessionId: string) => {
    try {
      const response = await fetch(`/api/verify?sessionId=${sessionId}`, {
        method: "GET",
      })

      const data: VerificationResponse = await response.json()

      if (!data.success || !data.data) {
        throw new Error(data.error || "Failed to check verification status")
      }

      const { status, message } = data.data

      setState((prev) => ({
        ...prev,
        status,
        message: message || getStatusMessage(status),
      }))

      return status
    } catch (error) {
      setState((prev) => ({
        ...prev,
        status: "error",
        message: "Failed to check verification status",
        error: error instanceof Error ? error.message : "Unknown error",
      }))
      return "error" as VerificationStatus
    }
  }, [])

  const startPolling = useCallback(
    (sessionId: string) => {
      if (pollingInterval) {
        clearInterval(pollingInterval)
      }

      // Set up polling every 5 seconds
      const interval = setInterval(async () => {
        const status = await checkVerificationStatus(sessionId)

        // Stop polling if we reach a terminal state
        if (status === "verified" || status === "expired" || status === "error") {
          clearInterval(interval)
          setPollingInterval(null)
        }
      }, 5000)

      setPollingInterval(interval)

      // Set up expiration timeout (60 seconds)
      setTimeout(() => {
        if (state.status !== "verified") {
          clearInterval(interval)
          setPollingInterval(null)
          setState((prev) => ({
            ...prev,
            status: "expired",
            message: "Verification expired. Please try again.",
          }))
        }
      }, 60000)

      return interval
    },
    [checkVerificationStatus, pollingInterval, state.status],
  )

  const resetVerification = useCallback(async () => {
    if (pollingInterval) {
      clearInterval(pollingInterval)
      setPollingInterval(null)
    }

    const sessionId = await fetchQRCode()
    if (sessionId) {
      startPolling(sessionId)
    }
  }, [fetchQRCode, pollingInterval, startPolling])

  // Initialize verification on mount
  useEffect(() => {
    const initVerification = async () => {
      const sessionId = await fetchQRCode()
      if (sessionId) {
        startPolling(sessionId)
      }
    }

    initVerification()

    // Cleanup on unmount
    return () => {
      if (pollingInterval) {
        clearInterval(pollingInterval)
      }
    }
  }, [fetchQRCode, startPolling, pollingInterval])

  return {
    ...state,
    resetVerification,
  }
}

function getStatusMessage(status: VerificationStatus): string {
  switch (status) {
    case "pending":
      return "Please scan the QR code with the Self Protocol app"
    case "verifying":
      return "Verifying your identity..."
    case "verified":
      return "Identity verified successfully!"
    case "expired":
      return "Verification expired. Please try again."
    case "error":
      return "Verification failed. Please try again."
    default:
      return "Unknown status"
  }
}

