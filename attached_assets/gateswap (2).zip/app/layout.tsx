import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { VerificationProvider } from "@/contexts/verification-context"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "GateSwap - Secure Cross-Chain Swapping",
  description: "One-click identity verification and cross-chain token swapping",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <VerificationProvider>{children}</VerificationProvider>
      </body>
    </html>
  )
}



import './globals.css'