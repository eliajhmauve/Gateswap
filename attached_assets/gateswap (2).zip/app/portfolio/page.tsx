"use client"

import { Layout } from "@/components/layout"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ProtectedRoute } from "@/components/protected-route"

export default function PortfolioPage() {
  return (
    <ProtectedRoute>
      <Layout>
        <div className="text-center mb-8">
          <h1 className="text-4xl md:text-5xl font-bold mb-2">
            Your
            <br />
            Portfolio
          </h1>
          <p className="text-white/60 max-w-md mx-auto">Track your multi-chain assets in one place</p>
        </div>

        <Card className="w-full max-w-4xl bg-white/5 backdrop-blur-lg border-white/10 shadow-xl">
          <CardContent className="p-6">
            <Tabs defaultValue="assets" className="w-full">
              <TabsList className="w-full bg-white/5 p-1 mb-6">
                <TabsTrigger value="assets" className="flex-1 data-[state=active]:bg-white/10">
                  Assets
                </TabsTrigger>
                <TabsTrigger value="activity" className="flex-1 data-[state=active]:bg-white/10">
                  Activity
                </TabsTrigger>
                <TabsTrigger value="analytics" className="flex-1 data-[state=active]:bg-white/10">
                  Analytics
                </TabsTrigger>
              </TabsList>

              <TabsContent value="assets" className="space-y-4">
                <div className="flex justify-between items-center">
                  <h2 className="text-xl font-bold">Your Assets</h2>
                  <Button variant="outline" className="rounded-full bg-white/5 border-white/10 hover:bg-white/10">
                    Connect Wallet
                  </Button>
                </div>

                <div className="text-center py-12">
                  <p className="text-white/60">Connect your wallet to view your assets</p>
                </div>
              </TabsContent>

              <TabsContent value="activity">
                <div className="text-center py-12">
                  <p className="text-white/60">Connect your wallet to view your activity</p>
                </div>
              </TabsContent>

              <TabsContent value="analytics">
                <div className="text-center py-12">
                  <p className="text-white/60">Connect your wallet to view your analytics</p>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </Layout>
    </ProtectedRoute>
  )
}

