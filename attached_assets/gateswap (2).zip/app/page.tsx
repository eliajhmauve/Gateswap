"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useVerification } from "@/contexts/verification-context"
import { Layout } from "@/components/layout"
import { LoadingScreen } from "@/components/loading-screen"

export default function HomePage() {
  const { isVerified, isLoading } = useVerification()
  const router = useRouter()

  useEffect(() => {
    if (!isLoading) {
      // Redirect based on verification status
      if (isVerified) {
        router.replace("/swap")
      } else {
        router.replace("/verify")
      }
    }
  }, [isVerified, isLoading, router])

  // Show loading screen while checking verification status
  if (isLoading) {
    return <LoadingScreen />
  }

  // This content won't be shown as we're redirecting
  return (
    <Layout>
      <div className="text-center">
        <p>Redirecting...</p>
      </div>
    </Layout>
  )
}

