import { type NextRequest, NextResponse } from "next/server"

// In-memory store for verification sessions (in a real app, use a database)
const sessions: Record<
  string,
  {
    status: string
    createdAt: number
    qrCodeUrl: string
  }
> = {}

export async function POST(request: NextRequest) {
  try {
    // Generate a random session ID
    const sessionId = Math.random().toString(36).substring(2, 15)

    // In a real implementation, you would call the Self Protocol API to generate a QR code
    // This is a mock response for demonstration purposes
    const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=self-protocol:verify:${sessionId}`

    // Store the session
    sessions[sessionId] = {
      status: "pending",
      createdAt: Date.now(),
      qrCodeUrl,
    }

    return NextResponse.json({
      success: true,
      data: {
        qrCodeUrl,
        sessionId,
        status: "pending",
      },
    })
  } catch (error) {
    console.error("Error generating QR code:", error)
    return NextResponse.json({ success: false, error: "Failed to generate QR code" }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const sessionId = searchParams.get("sessionId")

    if (!sessionId) {
      return NextResponse.json({ success: false, error: "Session ID is required" }, { status: 400 })
    }

    const session = sessions[sessionId]

    if (!session) {
      return NextResponse.json({ success: false, error: "Session not found" }, { status: 404 })
    }

    // Check if the session has expired (60 seconds)
    if (Date.now() - session.createdAt > 60000) {
      session.status = "expired"
    }

    // In a real implementation, you would check the actual status from Self Protocol
    // For demo purposes, we'll simulate the verification flow
    if (session.status === "pending") {
      // Randomly transition to verifying state after a few calls
      if (Math.random() > 0.7) {
        session.status = "verifying"
      }
    } else if (session.status === "verifying") {
      // Randomly transition to verified state after a few calls
      if (Math.random() > 0.6) {
        session.status = "verified"
      }
    }

    return NextResponse.json({
      success: true,
      data: {
        status: session.status,
        sessionId,
        qrCodeUrl: session.qrCodeUrl,
      },
    })
  } catch (error) {
    console.error("Error checking verification status:", error)
    return NextResponse.json({ success: false, error: "Failed to check verification status" }, { status: 500 })
  }
}

