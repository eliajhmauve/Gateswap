"use client"

import { useEffect } from "react"
import { motion } from "framer-motion"
import { Layout } from "@/components/layout"
import { Card, CardContent } from "@/components/ui/card"
import { QRCodeDisplay } from "@/components/qr-code-display"
import { VerificationProgress } from "@/components/verification-progress"
import { useQRVerification } from "@/hooks/use-qr-verification"
import { useVerification } from "@/contexts/verification-context"
import { Shield } from "lucide-react"

export default function VerifyPage() {
  const { status, qrCodeUrl, message, resetVerification } = useQRVerification()
  const { setVerified } = useVerification()

  // Update verification status when verification is successful
  useEffect(() => {
    if (status === "verified") {
      const successTimer = setTimeout(() => {
        setVerified(true)
        // No need to manually redirect as the context will handle it
      }, 2000) // Delay for 2 seconds to show success state

      return () => clearTimeout(successTimer)
    }
  }, [status, setVerified])

  return (
    <Layout>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md"
      >
        <div className="text-center mb-8">
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.2, duration: 0.5 }}
            className="w-20 h-20 rounded-full bg-gradient-to-r from-purple-600 to-pink-600 flex items-center justify-center mx-auto mb-6"
          >
            <Shield className="h-10 w-10" />
          </motion.div>

          <h1 className="text-4xl md:text-5xl font-bold mb-2">
            Identity
            <br />
            Verification
          </h1>
          <p className="text-white/60 max-w-md mx-auto">
            Scan the QR code with the Self Protocol app to verify your identity
          </p>
        </div>

        <Card className="bg-white/5 backdrop-blur-lg border-white/10 shadow-xl overflow-hidden">
          <CardContent className="p-8">
            <VerificationProgress status={status} />

            <QRCodeDisplay qrCodeUrl={qrCodeUrl} status={status} message={message} onReset={resetVerification} />

            <div className="mt-6 text-center">
              <p className="text-xs text-white/60">
                Your data is securely processed using Self Protocol and never stored
              </p>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </Layout>
  )
}

