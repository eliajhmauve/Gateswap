"use client"

import { Layout } from "@/components/layout"
import { SwapCard } from "@/components/swap-card"
import { ProtectedRoute } from "@/components/protected-route"

export default function SwapPage() {
  return (
    <ProtectedRoute>
      <Layout>
        <div className="text-center mb-8">
          <h1 className="text-4xl md:text-5xl font-bold mb-2">
            Cross-Chain
            <br />
            Swapping
          </h1>
          <p className="text-white/60 max-w-md mx-auto">Swap tokens across different blockchains with just one click</p>
        </div>

        <SwapCard />
      </Layout>
    </ProtectedRoute>
  )
}

