"use client"

import type { ReactNode } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { ConnectButton } from "./connect-button"
import { AnimatedBackground } from "./animated-background"
import { Search } from "lucide-react"
import { Input } from "@/components/ui/input"
import { useVerification } from "@/contexts/verification-context"

interface LayoutProps {
  children: ReactNode
}

export function Layout({ children }: LayoutProps) {
  const pathname = usePathname()
  const { isVerified } = useVerification()

  const navItems = [
    { name: "Swap", path: "/swap", requiresVerification: true },
    { name: "Explore", path: "/explore", requiresVerification: false },
    { name: "Pool", path: "/pool", requiresVerification: true },
    { name: "Portfolio", path: "/portfolio", requiresVerification: true },
  ]

  // Filter nav items based on verification status
  const visibleNavItems = navItems.filter(
    (item) => !item.requiresVerification || (item.requiresVerification && isVerified),
  )

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white overflow-hidden relative">
      <AnimatedBackground />

      {/* Navigation */}
      <header className="relative z-10 border-b border-white/10 backdrop-blur-md bg-black/20">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center space-x-6">
            <Link href="/" className="flex items-center">
              <div className="flex items-center">
                <span className="text-xl font-bold bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent">
                  GateSwap
                </span>
              </div>
            </Link>
            <nav className="hidden md:flex space-x-6">
              {visibleNavItems.map((item) => (
                <Link
                  key={item.path}
                  href={item.path}
                  className={`text-sm font-medium ${
                    pathname === item.path ? "text-white" : "text-white/60 hover:text-white"
                  } transition-colors`}
                >
                  {item.name}
                </Link>
              ))}
              {!isVerified && (
                <Link
                  href="/verify"
                  className={`text-sm font-medium ${
                    pathname === "/verify" ? "text-white" : "text-white/60 hover:text-white"
                  } transition-colors`}
                >
                  Verify Identity
                </Link>
              )}
            </nav>
          </div>

          <div className="flex items-center space-x-3">
            <div className="relative hidden md:block">
              <Input
                type="text"
                placeholder="Search tokens"
                className="w-64 bg-white/5 border-white/10 rounded-full text-sm pl-10 h-10 focus:border-purple-500 focus:ring-purple-500/20"
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-white/40 w-4 h-4" />
            </div>

            <ConnectButton />
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 relative z-10 flex flex-col items-center justify-center min-h-[calc(100vh-76px)]">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-black/30 backdrop-blur-md border-t border-white/10 py-8 relative z-10">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center mb-4">
                <span className="text-xl font-bold bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent">
                  GateSwap
                </span>
              </div>
              <p className="text-white/60 mb-4">Secure, simple, and beautiful one-stop crypto exchange platform</p>
            </div>

            <div>
              <h3 className="font-bold mb-4">Product</h3>
              <ul className="space-y-2">
                {isVerified && (
                  <li>
                    <Link href="/swap" className="text-white/60 hover:text-white transition-colors">
                      Swap
                    </Link>
                  </li>
                )}
                <li>
                  <Link href="/bridge" className="text-white/60 hover:text-white transition-colors">
                    Bridge
                  </Link>
                </li>
                {isVerified && (
                  <li>
                    <Link href="/pool" className="text-white/60 hover:text-white transition-colors">
                      Pool
                    </Link>
                  </li>
                )}
                {isVerified && (
                  <li>
                    <Link href="/portfolio" className="text-white/60 hover:text-white transition-colors">
                      Portfolio
                    </Link>
                  </li>
                )}
              </ul>
            </div>

            <div>
              <h3 className="font-bold mb-4">Support</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="/help" className="text-white/60 hover:text-white transition-colors">
                    Help Center
                  </Link>
                </li>
                <li>
                  <Link href="/docs" className="text-white/60 hover:text-white transition-colors">
                    Documentation
                  </Link>
                </li>
                <li>
                  <Link href="/api" className="text-white/60 hover:text-white transition-colors">
                    API
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="text-white/60 hover:text-white transition-colors">
                    Contact Us
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-bold mb-4">Legal</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="/privacy" className="text-white/60 hover:text-white transition-colors">
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link href="/terms" className="text-white/60 hover:text-white transition-colors">
                    Terms of Service
                  </Link>
                </li>
                <li>
                  <Link href="/disclaimer" className="text-white/60 hover:text-white transition-colors">
                    Disclaimer
                  </Link>
                </li>
                <li>
                  <Link href="/compliance" className="text-white/60 hover:text-white transition-colors">
                    Compliance
                  </Link>
                </li>
              </ul>
            </div>
          </div>

          <div className="mt-8 pt-6 border-t border-white/10 flex flex-col md:flex-row justify-between items-center">
            <p className="text-white/60 text-sm mb-4 md:mb-0">© 2025 GateSwap. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

