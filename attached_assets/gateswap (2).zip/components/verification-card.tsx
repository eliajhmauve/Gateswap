"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Shield, Check, ArrowRight } from "lucide-react"
import { SwapCard } from "./swap-card"

export function VerificationCard() {
  const [isVerified, setIsVerified] = useState(false)
  const [isVerifying, setIsVerifying] = useState(false)

  const handleVerify = () => {
    setIsVerifying(true)

    // Simulate verification process
    setTimeout(() => {
      setIsVerifying(false)
      setIsVerified(true)
    }, 2000)
  }

  return (
    <AnimatePresence mode="wait">
      {!isVerified ? (
        <motion.div
          key="verification"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.3 }}
          className="w-full max-w-md"
        >
          <Card className="bg-white/5 backdrop-blur-lg border-white/10 shadow-xl">
            <CardContent className="p-8 flex flex-col items-center text-center">
              <div className="w-20 h-20 rounded-full bg-gradient-to-r from-purple-600 to-pink-600 flex items-center justify-center mb-6">
                <Shield className="h-10 w-10" />
              </div>

              <h2 className="text-2xl font-bold mb-2">Identity Verification</h2>
              <p className="text-white/60 mb-6">
                Complete a quick identity verification to ensure compliance and unlock all features
              </p>

              <div className="w-full space-y-4 mb-6">
                <div className="flex items-center p-3 bg-white/5 rounded-lg">
                  <div className="w-8 h-8 rounded-full bg-green-500/20 flex items-center justify-center mr-3">
                    <Check className="h-4 w-4 text-green-500" />
                  </div>
                  <div className="text-left">
                    <div className="font-medium">Age Verification</div>
                    <div className="text-sm text-white/60">Verify you are of legal age</div>
                  </div>
                </div>

                <div className="flex items-center p-3 bg-white/5 rounded-lg">
                  <div className="w-8 h-8 rounded-full bg-green-500/20 flex items-center justify-center mr-3">
                    <Check className="h-4 w-4 text-green-500" />
                  </div>
                  <div className="text-left">
                    <div className="font-medium">Nationality Check</div>
                    <div className="text-sm text-white/60">Confirm your country of residence</div>
                  </div>
                </div>

                <div className="flex items-center p-3 bg-white/5 rounded-lg">
                  <div className="w-8 h-8 rounded-full bg-green-500/20 flex items-center justify-center mr-3">
                    <Check className="h-4 w-4 text-green-500" />
                  </div>
                  <div className="text-left">
                    <div className="font-medium">OFAC Compliance</div>
                    <div className="text-sm text-white/60">Ensure regulatory compliance</div>
                  </div>
                </div>
              </div>

              <Button
                className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white py-6 rounded-full"
                onClick={handleVerify}
                disabled={isVerifying}
              >
                {isVerifying ? (
                  <div className="flex items-center">
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                    Verifying...
                  </div>
                ) : (
                  <div className="flex items-center justify-center">
                    Verify Identity
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </div>
                )}
              </Button>

              <p className="text-xs text-white/60 mt-4">
                Your data is securely processed using Self Protocol and never stored
              </p>
            </CardContent>
          </Card>
        </motion.div>
      ) : (
        <motion.div
          key="swap"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="w-full max-w-md"
        >
          <SwapCard />
        </motion.div>
      )}
    </AnimatePresence>
  )
}

