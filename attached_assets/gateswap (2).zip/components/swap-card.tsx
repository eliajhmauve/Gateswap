"use client"

import { useState } from "react"
import { ArrowDown, Info } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { TokenSelector } from "./token-selector"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

const tokens = [
  {
    symbol: "ETH",
    name: "Ethereum",
    logo: "/placeholder.svg?height=32&width=32",
    balance: "1.234",
  },
  {
    symbol: "USDT",
    name: "Tether USD",
    logo: "/placeholder.svg?height=32&width=32",
    balance: "2,345.67",
  },
  {
    symbol: "BTC",
    name: "Bitcoin",
    logo: "/placeholder.svg?height=32&width=32",
    balance: "0.123",
  },
  {
    symbol: "BNB",
    name: "Binance Coin",
    logo: "/placeholder.svg?height=32&width=32",
    balance: "12.345",
  },
  {
    symbol: "SOL",
    name: "Solana",
    logo: "/placeholder.svg?height=32&width=32",
    balance: "123.45",
  },
]

export function SwapCard() {
  const [fromToken, setFromToken] = useState("ETH")
  const [toToken, setToToken] = useState("USDT")
  const [fromAmount, setFromAmount] = useState("")
  const [toAmount, setToAmount] = useState("")

  const handleSwapTokens = () => {
    const tempToken = fromToken
    setFromToken(toToken)
    setToToken(tempToken)

    const tempAmount = fromAmount
    setFromAmount(toAmount)
    setToAmount(tempAmount)
  }

  return (
    <Card className="w-full max-w-md bg-white/5 backdrop-blur-lg border-white/10 shadow-xl">
      <CardContent className="p-6 space-y-4">
        {/* From section */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-white/60">From</span>
            <span className="text-white/60">Balance: {tokens.find((t) => t.symbol === fromToken)?.balance || "0"}</span>
          </div>
          <div className="flex items-center p-4 bg-white/5 rounded-lg border border-white/10">
            <Input
              type="text"
              value={fromAmount}
              onChange={(e) => setFromAmount(e.target.value)}
              placeholder="0"
              className="bg-transparent border-none text-2xl font-medium focus:outline-none focus:ring-0 p-0 w-full"
            />
            <div className="flex items-center ml-2">
              <TokenSelector value={fromToken} onChange={setFromToken} tokens={tokens} />
            </div>
          </div>
        </div>

        {/* Swap button */}
        <div className="flex justify-center">
          <Button
            variant="ghost"
            size="icon"
            onClick={handleSwapTokens}
            className="bg-white/5 hover:bg-white/10 rounded-full h-10 w-10"
          >
            <ArrowDown className="h-4 w-4" />
          </Button>
        </div>

        {/* To section */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-white/60">To</span>
            <span className="text-white/60">Balance: {tokens.find((t) => t.symbol === toToken)?.balance || "0"}</span>
          </div>
          <div className="flex items-center p-4 bg-white/5 rounded-lg border border-white/10">
            <Input
              type="text"
              value={toAmount}
              onChange={(e) => setToAmount(e.target.value)}
              placeholder="0"
              className="bg-transparent border-none text-2xl font-medium focus:outline-none focus:ring-0 p-0 w-full"
            />
            <div className="flex items-center ml-2">
              <TokenSelector value={toToken} onChange={setToToken} tokens={tokens} />
            </div>
          </div>
        </div>

        {/* Transaction details */}
        <div className="bg-white/5 rounded-lg p-3 text-sm">
          <div className="flex justify-between mb-1">
            <div className="flex items-center text-white/60">
              <span>Rate</span>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Info className="h-3 w-3 ml-1 cursor-help" />
                  </TooltipTrigger>
                  <TooltipContent className="bg-gray-900 border-white/10">
                    <p>The current exchange rate</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
            <span>
              1 {fromToken} ≈ 1,820 {toToken}
            </span>
          </div>
          <div className="flex justify-between mb-1">
            <div className="flex items-center text-white/60">
              <span>Network Fee</span>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Info className="h-3 w-3 ml-1 cursor-help" />
                  </TooltipTrigger>
                  <TooltipContent className="bg-gray-900 border-white/10">
                    <p>The estimated gas fee for this transaction</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
            <span>≈ $2.50</span>
          </div>
          <div className="flex justify-between">
            <div className="flex items-center text-white/60">
              <span>Minimum Received</span>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Info className="h-3 w-3 ml-1 cursor-help" />
                  </TooltipTrigger>
                  <TooltipContent className="bg-gray-900 border-white/10">
                    <p>The minimum amount you will receive after slippage</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
            <span>0 {toToken}</span>
          </div>
        </div>

        {/* Swap button */}
        <Button className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white py-6 rounded-full">
          Connect Wallet
        </Button>
      </CardContent>
    </Card>
  )
}

