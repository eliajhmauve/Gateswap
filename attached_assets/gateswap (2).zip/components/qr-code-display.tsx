"use client"

import { motion } from "framer-motion"
import { Loader2, CheckCircle, AlertCircle, RefreshCw } from "lucide-react"
import { Button } from "@/components/ui/button"
import type { VerificationStatus } from "@/hooks/use-qr-verification"

interface QRCodeDisplayProps {
  qrCodeUrl: string | null
  status: VerificationStatus
  message: string
  onReset: () => void
}

export function QRCodeDisplay({ qrCodeUrl, status, message, onReset }: QRCodeDisplayProps) {
  return (
    <div className="flex flex-col items-center justify-center space-y-6">
      <div className="relative w-64 h-64 flex items-center justify-center">
        {/* QR Code Container */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{
            opacity: qrCodeUrl && status !== "verified" ? 1 : 0,
            scale: qrCodeUrl && status !== "verified" ? 1 : 0.9,
            filter: status === "pending" ? "blur(0px)" : "blur(3px)",
          }}
          transition={{ duration: 0.5 }}
          className="bg-white p-4 rounded-lg shadow-lg"
        >
          {qrCodeUrl ? (
            <img src={qrCodeUrl || "/placeholder.svg"} alt="Verification QR Code" className="w-56 h-56" />
          ) : (
            <div className="w-56 h-56 bg-gray-200 animate-pulse" />
          )}
        </motion.div>

        {/* Status Overlays */}
        {status === "verifying" && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="absolute inset-0 flex items-center justify-center bg-black/50 rounded-lg"
          >
            <Loader2 className="h-16 w-16 text-purple-500 animate-spin" />
          </motion.div>
        )}

        {status === "verified" && (
          <motion.div
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ type: "spring", stiffness: 200, damping: 15 }}
            className="absolute inset-0 flex items-center justify-center bg-black/50 rounded-lg"
          >
            <CheckCircle className="h-20 w-20 text-green-500" />
          </motion.div>
        )}

        {(status === "expired" || status === "error") && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="absolute inset-0 flex items-center justify-center bg-black/50 rounded-lg"
          >
            <AlertCircle className="h-16 w-16 text-red-500" />
          </motion.div>
        )}
      </div>

      {/* Status Message */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        key={message} // This forces re-animation when message changes
        className="text-center"
      >
        <p className="text-white/80 text-lg">{message}</p>
      </motion.div>

      {/* Reset Button (only shown for expired or error states) */}
      {(status === "expired" || status === "error") && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
          <Button
            onClick={onReset}
            className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white rounded-full px-6"
          >
            <RefreshCw className="mr-2 h-4 w-4" />
            Try Again
          </Button>
        </motion.div>
      )}
    </div>
  )
}

