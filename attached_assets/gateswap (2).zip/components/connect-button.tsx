"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Wallet, Shield, CheckCircle } from "lucide-react"
import { useVerification } from "@/contexts/verification-context"
import Link from "next/link"

export function ConnectButton() {
  const [isConnected, setIsConnected] = useState(false)
  const { isVerified } = useVerification()

  const handleConnect = () => {
    // In a real implementation, this would trigger wallet connection
    setIsConnected(true)
  }

  if (isConnected) {
    return (
      <div className="flex items-center space-x-2">
        {isVerified && (
          <div className="hidden md:flex items-center bg-green-500/10 text-green-400 px-2 py-1 rounded-full text-xs">
            <CheckCircle className="w-3 h-3 mr-1" />
            Verified
          </div>
        )}
        <Button variant="outline" className="rounded-full bg-white/5 border-white/10 hover:bg-white/10 text-white">
          <span className="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
          0x1a2b...3c4d
        </Button>
      </div>
    )
  }

  return (
    <div className="flex items-center space-x-2">
      {!isVerified && (
        <Link href="/verify">
          <Button
            variant="outline"
            className="rounded-full bg-gradient-to-r from-purple-600/20 to-pink-600/20 border-purple-500/30 hover:bg-white/10 text-white"
          >
            <Shield className="mr-2 h-4 w-4" />
            Verify
          </Button>
        </Link>
      )}
      <Button
        variant="outline"
        className="rounded-full bg-white/5 border-white/10 hover:bg-white/10 text-white"
        onClick={handleConnect}
      >
        <Wallet className="mr-2 h-4 w-4" />
        Connect
      </Button>
    </div>
  )
}

