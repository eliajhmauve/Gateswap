"use client"

import { useState } from "react"
import { Check, ChevronDown, Search } from "lucide-react"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { cn } from "@/lib/utils"

interface Token {
  symbol: string
  name: string
  logo: string
  balance?: string
}

interface TokenSelectorProps {
  value: string
  onChange: (value: string) => void
  tokens: Token[]
}

export function TokenSelector({ value, onChange, tokens }: TokenSelectorProps) {
  const [open, setOpen] = useState(false)
  const [search, setSearch] = useState("")

  const selectedToken = tokens.find((token) => token.symbol === value)

  const filteredTokens = tokens.filter(
    (token) =>
      token.symbol.toLowerCase().includes(search.toLowerCase()) ||
      token.name.toLowerCase().includes(search.toLowerCase()),
  )

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          role="combobox"
          aria-expanded={open}
          className="w-full justify-between border-none bg-white/10 rounded-full"
        >
          {selectedToken ? (
            <div className="flex items-center">
              <div className="w-6 h-6 rounded-full bg-white/10 mr-2 overflow-hidden">
                <img
                  src={selectedToken.logo || "/placeholder.svg"}
                  alt={selectedToken.symbol}
                  className="w-full h-full object-cover"
                />
              </div>
              <span>{selectedToken.symbol}</span>
            </div>
          ) : (
            <span>Select token</span>
          )}
          <ChevronDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[300px] p-0 bg-[#1a1a24] border-white/10">
        <div className="p-3 border-b border-white/10">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-white/40 w-4 h-4" />
            <Input
              placeholder="Search token name or symbol"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10 bg-white/5 border-white/10"
            />
          </div>
        </div>
        <div className="max-h-[300px] overflow-y-auto">
          {filteredTokens.map((token) => (
            <div
              key={token.symbol}
              className={cn(
                "flex items-center justify-between px-3 py-2 cursor-pointer hover:bg-white/5",
                value === token.symbol && "bg-white/10",
              )}
              onClick={() => {
                onChange(token.symbol)
                setOpen(false)
              }}
            >
              <div className="flex items-center">
                <div className="w-8 h-8 rounded-full bg-white/10 mr-3 overflow-hidden">
                  <img
                    src={token.logo || "/placeholder.svg"}
                    alt={token.symbol}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <div className="font-medium">{token.symbol}</div>
                  <div className="text-sm text-white/60">{token.name}</div>
                </div>
              </div>
              {token.balance && (
                <div className="text-right">
                  <div className="font-medium">{token.balance}</div>
                </div>
              )}
              {value === token.symbol && <Check className="h-4 w-4 text-purple-500" />}
            </div>
          ))}
        </div>
      </PopoverContent>
    </Popover>
  )
}

