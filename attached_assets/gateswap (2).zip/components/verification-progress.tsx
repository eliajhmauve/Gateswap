"use client"

import { motion } from "framer-motion"
import type { VerificationStatus } from "@/hooks/use-qr-verification"

interface VerificationProgressProps {
  status: VerificationStatus
}

export function VerificationProgress({ status }: VerificationProgressProps) {
  const steps = [
    { id: "pending", label: "Waiting for scan" },
    { id: "verifying", label: "Verifying" },
    { id: "verified", label: "Verified" },
  ]

  // Calculate the current step index
  const currentStepIndex = steps.findIndex((step) => step.id === status)
  const activeIndex = currentStepIndex === -1 ? 0 : currentStepIndex

  return (
    <div className="w-full max-w-md mx-auto mb-8">
      <div className="flex justify-between items-center">
        {steps.map((step, index) => (
          <div key={step.id} className="flex flex-col items-center relative">
            {/* Connecting line */}
            {index < steps.length - 1 && (
              <div className="absolute w-full h-0.5 bg-white/10 top-3 left-1/2">
                <motion.div
                  className="h-full bg-gradient-to-r from-purple-500 to-pink-500"
                  initial={{ width: "0%" }}
                  animate={{ width: activeIndex > index ? "100%" : "0%" }}
                  transition={{ duration: 0.5 }}
                />
              </div>
            )}

            {/* Step circle */}
            <motion.div
              className={`w-6 h-6 rounded-full flex items-center justify-center z-10 ${
                activeIndex >= index ? "bg-gradient-to-r from-purple-500 to-pink-500" : "bg-white/10"
              }`}
              animate={{
                scale: activeIndex === index ? [1, 1.1, 1] : 1,
              }}
              transition={{
                duration: 0.5,
                repeat: activeIndex === index ? Number.POSITIVE_INFINITY : 0,
                repeatDelay: 1.5,
              }}
            >
              {activeIndex > index ? (
                <svg
                  className="w-3 h-3 text-white"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                </svg>
              ) : (
                <span className="text-xs text-white">{index + 1}</span>
              )}
            </motion.div>

            {/* Step label */}
            <span className={`text-xs mt-2 ${activeIndex >= index ? "text-white" : "text-white/40"}`}>
              {step.label}
            </span>
          </div>
        ))}
      </div>
    </div>
  )
}

