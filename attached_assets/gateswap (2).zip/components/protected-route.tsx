"use client"

import { type ReactNode, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useVerification } from "@/contexts/verification-context"
import { LoadingScreen } from "./loading-screen"

interface ProtectedRouteProps {
  children: ReactNode
}

export function ProtectedRoute({ children }: ProtectedRouteProps) {
  const { isVerified, isLoading } = useVerification()
  const router = useRouter()

  useEffect(() => {
    if (!isLoading && !isVerified) {
      router.replace("/verify")
    }
  }, [isVerified, isLoading, router])

  if (isLoading) {
    return <LoadingScreen />
  }

  return isVerified ? <>{children}</> : null
}

