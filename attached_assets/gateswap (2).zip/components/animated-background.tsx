"use client"
import { motion } from "framer-motion"

export function AnimatedBackground() {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      <motion.div
        className="absolute top-1/4 left-1/4 w-40 h-40 rounded-full bg-purple-500/20 blur-3xl"
        animate={{
          x: [0, 20, 0, -20, 0],
          y: [0, -20, 0, 20, 0],
        }}
        transition={{
          duration: 15,
          repeat: Number.POSITIVE_INFINITY,
          repeatType: "loop",
          ease: "easeInOut",
        }}
      />
      <motion.div
        className="absolute top-3/4 left-1/2 w-60 h-60 rounded-full bg-blue-500/20 blur-3xl"
        animate={{
          x: [0, -30, 0, 30, 0],
          y: [0, 30, 0, -30, 0],
        }}
        transition={{
          duration: 18,
          repeat: Number.POSITIVE_INFINITY,
          repeatType: "loop",
          ease: "easeInOut",
        }}
      />
      <motion.div
        className="absolute top-1/2 right-1/4 w-40 h-40 rounded-full bg-pink-500/20 blur-3xl"
        animate={{
          x: [0, 40, 0, -40, 0],
          y: [0, 40, 0, -40, 0],
        }}
        transition={{
          duration: 20,
          repeat: Number.POSITIVE_INFINITY,
          repeatType: "loop",
          ease: "easeInOut",
        }}
      />
      <motion.div
        className="absolute bottom-1/4 left-1/3 w-40 h-40 rounded-full bg-green-500/20 blur-3xl"
        animate={{
          x: [0, -50, 0, 50, 0],
          y: [0, -50, 0, 50, 0],
        }}
        transition={{
          duration: 25,
          repeat: Number.POSITIVE_INFINITY,
          repeatType: "loop",
          ease: "easeInOut",
        }}
      />
      <motion.div
        className="absolute top-1/3 right-1/3 w-40 h-40 rounded-full bg-yellow-500/20 blur-3xl"
        animate={{
          x: [0, -60, 0, 60, 0],
          y: [0, 60, 0, -60, 0],
        }}
        transition={{
          duration: 30,
          repeat: Number.POSITIVE_INFINITY,
          repeatType: "loop",
          ease: "easeInOut",
        }}
      />
    </div>
  )
}

